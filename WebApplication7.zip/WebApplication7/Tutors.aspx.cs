﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication7
{
    public partial class Tutors : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
         
       //Map
            Response.Redirect("HTMLPage2.htm");
        
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //Weather
        }
    }
}