﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace WebApplication7
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button27_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "(";
        }

        protected void Button26_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + ")";
        }

        protected void Button25_Click(object sender, EventArgs e)
        {
            string DTxt = TextBox1.Text;
            int Indx = DTxt.Length;
            TextBox1.Text = TextBox1.Text.Remove(Indx - 1);

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            Label1.Text = "";
        }

        protected void Button21_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "7";
        }

        protected void Button22_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "8";
        }

        protected void Button23_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "9";
        }

        protected void Button24_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "/";
        }

        protected void Button28_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "4";
        }

        protected void Button30_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "5";
        }

        protected void Button31_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "6";
        }

        protected void Button32_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "*";
        }

        protected void Button29_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "1";
        }

        protected void Button35_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "2";
        }

        protected void Button34_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "3";

        }

        protected void Button33_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "-";
        }

        protected void Button39_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "0";
        }

        protected void Button38_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "(";
        }

        protected void Button37_Click(object sender, EventArgs e)
        {
            string Ip = TextBox1.Text;

            DataTable tb = new DataTable();

            Object sol;

            sol = tb.Compute(Ip, null);

            Label1.Text = sol.ToString();
        }

        protected void Button36_Click(object sender, EventArgs e)
        {
            TextBox1.Text = TextBox1.Text + "+";
        }

    }
}