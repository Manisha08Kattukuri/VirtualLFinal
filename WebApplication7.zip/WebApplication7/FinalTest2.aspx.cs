﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Net;
using System.IO;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;


namespace WebApplication7
{
    public partial class FinalTest2 : System.Web.UI.Page
    {
        
        public int qno = 1;
        public static SqlConnection sqlconn;
        protected string PostBackStr;
        Tform[] tForm = null;
        String qresult = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.Print("Length: ");
            System.Console.WriteLine("Hello");
            int qLength = 0;
            txtName.Text = Session["un"].ToString();
            sqlconn = new SqlConnection(@"Data Source=.\SQLSERV2014;AttachDbFilename=C:\Users\Manisha\Downloads\VirtualL\VirtualL\VirtualL\App_Data\OCA.mdf;Integrated Security=True;User Instance=True");
            WebRequest req = WebRequest.Create(@"http://localhost:41150/Service1.svc/queryinfo/cat/2");
            req.Method = "GET";
            req.ContentType = "application/json";
            HttpWebResponse resp = req.GetResponse() as HttpWebResponse;
            if (resp.StatusCode == HttpStatusCode.OK)
            {
                using (Stream respStream = resp.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(respStream, Encoding.UTF8);
                    qresult = reader.ReadToEnd();
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    tForm = js.Deserialize<Tform[]>(qresult);
                    qLength = tForm.Length;
                    System.Diagnostics.Debug.Print("Length: " + qLength);
                    //Label4.Text = "Q : "+ tForm[0].question;
                }
            }
            if (!IsPostBack)
            {
                string eventArg = Request["__EVENTARGUMENT"];
                if (eventArg == "time")
                {
                    getQuestion(qno);
                }
            }

        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            Label1.Visible = false;
            txtName.Visible = false;
            Button1.Visible = false;
            Panel1.Visible = true;
            lblName.Text = "Name : " + txtName.Text;
            int score = Convert.ToInt32(txtScore.Text);
            lblScore.Text = "Score : " + Convert.ToString(score);
            //Session["counter"] = "1";
            //Random rnd = new Random();
            //int i = rnd.Next(1, 30);//Here specify your starting slno of question table and ending no.
            //lblQuestion.Text = i.ToString();
            getQuestion(0);



        }


        protected void Button2_Click(object sender, EventArgs e)
        {

            if (qno < 10)
            {
                getQuestion(qno);
                qno = qno + 1;
            }
            else
            {
                Label1.Visible = false;
                txtName.Visible = false;
                Button1.Visible = false;
                Panel1.Visible = true;
                lblName.Text = "Succesfully completed the Test 1";
            }

        }



        public void getQuestion(int no)
        {
            int i = no;
            Session["Answer"] = tForm[i].answer;
            lblQuestion.Text = "Q" + (i + 1) + ". " + tForm[i].question + " ?";
            RblOption.ClearSelection();
            RblOption.Items.Clear();
            RblOption.Items.Add(tForm[i].options[0]);
            RblOption.Items.Add(tForm[i].options[1]);
            RblOption.Items.Add(tForm[i].options[2]);
            RblOption.Items.Add(tForm[i].options[3]);


        }

        int score = 0;
        public void getNextQuestion()
        {
            if (Convert.ToInt32(Session["counter"].ToString()) < 10)//20 is a counter which is used for 10 questions
            {
                if (RblOption.SelectedIndex >= 0)
                {
                    if (Session["Answer"].ToString() == RblOption.SelectedIndex.ToString())
                    {
                        score = Convert.ToInt32(txtScore.Text) + 3;// 1 for mark for each question
                        txtScore.Text = score.ToString();
                        lblScore.Text = "Score : " + Convert.ToString(score);
                    }
                    else
                    {
                        // score =Convert.ToInt16(txtScore.Text )- 1;
                    }
                }

                Random rnd = new Random();
                int i = rnd.Next(1, 30);
                // lblQuestion.Text = i.ToString();
                // getQuestion(i);
                Session["counter"] = Convert.ToString(Convert.ToInt32(Session["counter"].ToString()) + 1);

            }
            else
            {
                Panel2.Visible = false;
                //  lblScore.Text += score.ToString();
                //code for displaying after completting the exam, if you want to show the result then you can code here.
            }
        }

        //#region Connection Open
        //public void ConnectionOpen()
        //{
        //    try
        //    {
        //        if (sqlconn.State == ConnectionState.Closed) { sqlconn.Open(); }
        //    }
        //    catch (SqlException ex)
        //    {

        //    }
        //    catch (SystemException sex)
        //    {

        //    }
        //}
        //#endregion
        //#region Connection Close
        //public void ConnectionClose()
        //{
        //    try
        //    {
        //        if (sqlconn.State != ConnectionState.Closed) { sqlconn.Close(); }
        //    }
        //    catch (SqlException ex)
        //    {

        //    }
        //    catch (SystemException sex)
        //    {

        //    }
        //}
        //#endregion
        static int sec = 59;
        static int min = 9; //total time =10 mint , count down time is 9
        static int time = 0;
        static int examtime = 30; //muliple with 10, test time
        protected void Timer1_Tick(object sender, EventArgs e)
        {
            time++;
            sec--;
            if (sec < 0)
            {
                min--;
                sec = 59;
            }
            if (sec < 10)
            {
                Label2.Text = min + ": 0" + sec;
            }
            else
            {
                Label2.Text = min + ": " + sec;
            }
            // time++;

            if (time == examtime)
            {
                try
                {
                    Timer1.Enabled = false;
                    Button2.Enabled = false;
                    Label3.Visible = true;
                    Panel1.Visible = false;
                    Label3.Text = "Your First Session is Completed";
                    // lblScore.Visible = true;
                    Session.Add("test1score", lblScore.Text.ToString());
                    Button3.Visible = true;
                    Button3.Enabled = true;
                }
                catch
                {
                }
            }

        }



        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("FinalTest2.aspx");
        }

        protected void Timer2_Tick(object sender, EventArgs e)
        {

        }

        protected void txtScore_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            Response.Redirect("FinalTest3.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            //Panel4.Visible = true;
            Response.Redirect("Cal.aspx");
        }


    }
}